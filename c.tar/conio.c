#include "conio.h"

static struct termios old, new;

/* Initialize new terminal i/o settings */
void initTermios(int mytermios)
{
  tcgetattr(0, &old); /* grab old terminal i/o settings */
  new = old; /* make new settings same as old settings */
  new.c_lflag &= ~ICANON; /* disable buffered i/o */
  new.c_lflag &= mytermios ? mytermios : ~mytermios; /* set echo mode */
  tcsetattr(0, TCSANOW, &new); /* use these new terminal i/o settings now */
}

/* Restore old terminal i/o settings */
void resetTermios(void) 
{
  tcsetattr(0, TCSANOW, &old);
}

/* Read 1 character - echo defines echo mode */
char getch_(int mytermios) 
{
  char ch;
  initTermios(mytermios);
  ch = getchar();
  if(ch == '\x1b'){
    if(getchar()=='[') {
      switch(getchar()){
      case 'A':
        ch = '8';
        break;
      case 'B':
        ch = '2';
        break;
      case 'C':
        ch = '6';
        break;
      case 'D':
        ch = '4';
        break;
      }
    }
  }
  resetTermios();
  return ch;
}

/* Read 1 character without mytermios */
char getch(void) 
{
  return getch_(0);
}

/* Read 1 character with mytermios */
char getche(void) 
{
  return getch_(1);
}

